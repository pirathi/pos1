<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Connector\\Providers\\ConnectorServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Connector\\Providers\\ConnectorServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);