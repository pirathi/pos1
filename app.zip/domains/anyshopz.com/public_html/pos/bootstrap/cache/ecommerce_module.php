<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ecommerce\\Providers\\EcommerceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ecommerce\\Providers\\EcommerceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);